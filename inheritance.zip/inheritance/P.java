package inheritance;

public class P {
	int d =1;
	int d1 = 10;
	public void fun() {
		System.out.println("Fun in P");
	}
	public void fun1() {
		System.out.println("Fun1 in P");
	}
}
